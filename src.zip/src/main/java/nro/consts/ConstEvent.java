package nro.consts;

/**
 * @author Văn Tuấn - 0337766460
 */
public class ConstEvent {
    public static final byte KHONG_CO_SU_KIEN = 0;
    public static final byte SU_KIEN_HALLOWEEN = 1;
    public static final byte SU_KIEN_20_11 = 2;
    public static final byte SU_KIEN_NOEL = 3;
    public static final byte SU_KIEN_TET = 4;
    public static final byte SU_KIEN_8_3 = 5;
    public static final byte TET_2024 = 6;
}
