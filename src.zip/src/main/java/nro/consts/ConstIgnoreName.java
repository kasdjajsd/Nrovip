package nro.consts;

/**
 *
 * @author Văn Tuấn - 0337766460
 * @copyright 💖 GirlkuN 💖
 *
 */
public class ConstIgnoreName {

    public static final String[] IGNORE_NAME = {
        "songoku", "vegeta", "gohan", "gokussj", "songohan", "picolo", "pocolo", "bunma", "chichi",
        "quylao", "quylaokame", "hakai", "vegetahakai", "ditmeadmin", "gamerac", "gameloz", "dmmadmin", "sucvatadmin", "sucvat", "gohan",
        "gauxayda", "loladmin", "svadmin", "adnhuloz", "adnhulon", "kakarot", "admin", "billes", "svrac", "bahatmit", "bomong", "nrolove", "vegeto",
        "miximoi", "ditmeadmin", "dmadmin", "ptagaming", "ptalove", "truwg", "girlkun75", "girlkun", "toctruong", "loverac", "lovecc", "xayda", "namec", "traidat",
        "nroblue", "nrokakarot", "nrosuper", "nromegax", "nroprivate"
    };

}
