package consts;

public enum SocketType {
    CLIENT,
    SERVER
}