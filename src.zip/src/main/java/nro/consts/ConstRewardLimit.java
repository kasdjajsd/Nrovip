package nro.consts;

/**
 * @author Văn Tuấn - 0337766460
 */
public class ConstRewardLimit {
    public static final byte NUOC_SUOI_TINH_KHIET = 0;
    public static final byte GO_LON = 1;
    public static final byte CANH_KHO = 2;
    public static final byte QUE_DOT = 3;
    public static final byte BO_KIEN_VUONG_HAI_SUNG = 4;
    public static final byte BO_HUNG_TE_GIAC = 5;
    public static final byte BO_KEP_KIM = 6;
}
