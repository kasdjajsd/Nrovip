package consts;
public class ConstIgnoreName {

    public static final String[] IGNORE_NAME = {};

}
