/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nro.models.item;

/**
 *
 * @author Kitak
 */
public class FlagBag {

    public int id;
    public short iconId;
    public short[] iconEffect;
    public String name;
    public int gold;
    public int gem;
}
