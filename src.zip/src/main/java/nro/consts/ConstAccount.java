package nro.consts;

/**
 *
 * @author Văn Tuấn - 0337766460
 * @copyright 💖 GirlkuN 💖
 *
 */
public class ConstAccount {

    public static final byte DEFAUT = -1;
    public static final byte IS_INGAME = 0;
    public static final byte CAN_LOGIN = 1;
    public static final byte WRONG_ACCOUNT = 2;
    public static final byte IS_BAN = 3;

}
