package consts;

public class ConstTaskBadges {
    public static final byte DAI_GIA_MOI_NHU = 1;
    public static final byte TRUM_UOC_RONG = 2;
    public static final byte TRUM_SAN_BOSS = 3;
    public static final byte THANH_DAP_DO_7 = 4;
    public static final byte CAO_THU_SIEU_HANG = 5;
    public static final byte NONG_DAN_CHAM_CHI = 6;
    public static final byte KE_THAO_TUNG_SOI = 7;
    public static final byte NUOC_ANH_BAO = 8;
    public static final byte ONG_THAN_VE_CHAI = 9;
    public static final byte BI_MOC_SACH_TUI = 10;
    public static final byte O_DO = 11;

}
