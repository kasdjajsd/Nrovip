/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nro.login;

/**
 *
 * @author Văn Tuấn - 0337766460
 */
public class Cmd {

    public static final byte LOGIN = 1;
    public static final byte LOGOUT = 2;
    public static final byte DISCONNECT = 3;
    public static final byte SERVER_MESSAGE = 4;
    public static final byte SERVER = 5;
    public static final byte UPDATE_TIME_LOGOUT = 6;
}
