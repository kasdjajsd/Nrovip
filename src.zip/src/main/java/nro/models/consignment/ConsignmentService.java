package nro.models.consignment;

import nro.models.player.Player;
import nro.server.io.Message;

import java.io.DataInputStream;
import java.io.IOException;

/**
 * @author Văn Tuấn - 0337766460
 */
public class ConsignmentService {


}
