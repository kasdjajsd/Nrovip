package nro.models.clan;

/**
 * @author Văn Tuấn - 0337766460
 */
public enum Buff {
    NONE, BUFF_ATK, BUFF_HP, BUFF_KI, BUFF_CRIT
}
