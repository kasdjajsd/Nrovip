package consts;
public class ConstEvent {
    public static final byte KHONG_CO_SU_KIEN = 0;
    public static final byte SU_KIEN_HALLOWEEN = 1;
    public static final byte SU_KIEN_20_11 = 2;
    public static final byte SU_KIEN_NOEL = 3;
    public static final byte SU_KIEN_TET = 4;
    public static final byte SU_KIEN_HUNG_VUONG = 5;
    public static final byte SU_KIEN_TRUNG_THU = 6;
    public static final byte SU_KIEN_HE = 7;
    public static final byte SU_KIEN_VALENTINE = 8;
}