/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nro.models.item;

/**
 *
 * @author Kitak
 */
public class ItemOptionTemplate {

    public int id;

    public String name;

    public int type;

    public ItemOptionTemplate() {
    }

    public ItemOptionTemplate(int id, String name, int type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }
}
