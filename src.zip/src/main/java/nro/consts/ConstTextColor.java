package nro.consts;

/**
 * @author Văn Tuấn - 0337766460
 */
public class ConstTextColor {
    public static final byte BROWN = 0;
    public static final byte GREEN_BOLD = 1;
    public static final byte BLUE = 2;
    public static final byte PINK = 3;
    public static final byte GREEN = 4;

    public static final byte RED = 5;
}
