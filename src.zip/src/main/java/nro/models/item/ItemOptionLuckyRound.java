/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nro.models.item;

import nro.models.item.ItemOption;

/**
 *
 * @author Kitak
 */
public class ItemOptionLuckyRound {

    public ItemOption itemOption;
    public int param1;
    public int param2;

    public ItemOptionLuckyRound() {
        this.param2 = -1;
    }
}
