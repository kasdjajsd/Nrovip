package nro.models.boss.iboss;

/**
 *
 * @author Văn Tuấn - 0337766460
 * @copyright 💖 GirlkuN 💖
 *
 */
public interface IBossOutfit {

    short getHead();

    short getBody();

    short getLeg();

}
